package sfnp;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class staffdetails
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton insertButton,deleteButton,updateButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lblusername,lblsfname,lblsfaddress,lblsfid,lblsfqualification,lblsfemail,lblsfmobile,lblpassword;
	private JTextField txtusername,txtsfname,txtsfaddress,txtsfid,txtsfqualification,txtsfemail,txtsfmobile,txtpassword;

	private List MIDList;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public staffdetails(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		
		lblusername=new JLabel("User id");
		lblsfname=new JLabel("Staff Name");
		lblsfaddress=new JLabel("Staff Address");
		lblsfid=new JLabel("Staff id");
		lblsfqualification=new JLabel("Staff Qualification");
		lblsfemail=new JLabel("staff email");
		lblsfmobile=new JLabel("Staff Mobile");
		lblpassword=new JLabel("Password");

		txtusername=new JTextField(50);
		txtsfname=new JTextField(50);
		txtsfaddress=new JTextField(100);
		txtsfid=new JTextField(20);
		txtsfqualification =new JTextField(500);
		txtsfemail=new JTextField(20);
		txtsfmobile=new JTextField(10);
		txtpassword=new JTextField(20);
		
		this.p=p;
		
		
		
	}

	public void connectToDB() 
	{
		try {
		  
		
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","rohith","vasavi");  
		  
		 
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		
		
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
		
		
	}
	public void loadMedIDs() {
		try {
			MIDList.removeAll();
			rs=statement.executeQuery("select sfid from staffdetails");
			while(rs.next()) {
				MIDList.add(rs.getString("sfid"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}

	public void buildGUI() {
		
		
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				insertButton=new JButton("Submit");
				txtusername.setText(null);
				txtsfname.setText(null);
				txtsfaddress.setText(null);
				txtsfid.setText(null);
				txtsfqualification.setText(null);
				txtsfemail.setText(null);
				txtsfmobile.setText(null);
				txtpassword.setText(null);
				
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(8,2));
				 p1.add(lblusername);
				 p1.add(txtusername);
				 p1.add(lblsfname);
				 p1.add(txtsfname);
				 p1.add(lblsfaddress);
				 p1.add(txtsfaddress);
				 p1.add(lblsfid);
				 p1.add(txtsfid);
				 p1.add(lblsfqualification);
				 p1.add(txtsfqualification);
				 p1.add(lblsfemail);
				 p1.add(txtsfemail);
				 p1.add(lblsfmobile);
				 p1.add(txtsfmobile);
				 p1.add(lblpassword);
				 p1.add(txtpassword);
				
				
				 p3=new JPanel(new FlowLayout());
				 p3.add(insertButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.yellow);
				 p1.setBounds(115,80,300,250);p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.pink) ;
				 
				
					 
				 
				
				 p2 = new JPanel(new FlowLayout());
					
					 MIDList=new List(10);
					 loadMedIDs();
					 p2.add(MIDList);p2.setBackground(Color.cyan) ;
					 
					 p2.setBounds(450,150,350,180);
				 
				 
				 p. add(p1);p.add(p3);
				 p. add(p2);
				 
				
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
					
				 insertButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO staffdetails VALUES('"+txtusername.getText()+"','"+txtsfname.getText()+"','"+txtsfaddress.getText()+"',"+txtsfid.getText()+",'"+txtsfqualification.getText()+"','"+txtsfemail.getText()+"',"+txtsfmobile.getText()+","+txtpassword.getText()+")";
					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully");loadMedIDs();
					
					
					
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("delete");
				txtusername.setText(null);
				txtsfname.setText(null);
				txtsfaddress.setText(null);
				txtsfid.setText(null);
				txtsfqualification.setText(null);
				txtsfemail.setText(null);
				txtsfmobile.setText(null);
				txtpassword.setText(null);
				
				
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(8,2));
				 p1.add(lblusername);
				 p1.add(txtusername);
				 p1.add(lblsfname);
				 p1.add(txtsfname);
				 p1.add(lblsfaddress);
				 p1.add(txtsfaddress);
				 p1.add(lblsfid);
				 p1.add(txtsfid);
				 p1.add(lblsfqualification);
				 p1.add(txtsfqualification);
				 p1.add(lblsfemail);
				 p1.add(txtsfemail);
				 p1.add(lblsfmobile);
				 p1.add(txtsfmobile);
				 p1.add(lblpassword);
				 p1.add(txtpassword);
				 
				
				
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.yellow);
				 p1.setBounds(115,80,300,250);p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.pink) ;
				 
				
					 
				// p1.setBounds(100,100,500,300);
				
				 p2 = new JPanel(new FlowLayout());
					
					 MIDList=new List(10);
					 loadMedIDs();
					 p2.add(MIDList);p2.setBackground(Color.cyan) ;
					 
					 p2.setBounds(450,150,350,180);
				 
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				  MIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from staffdetails");
								while (rs.next()) 
								{
									if (rs.getString("sfid").equals(MIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtusername.setText(rs.getString("username"));
									txtsfname.setText(rs.getString("sfname"));
									txtsfaddress.setText(rs.getString("sfaddress"));
									txtsfid.setText(rs.getString("sfid"));
									txtsfqualification.setText(rs.getString("sfqualification"));
									txtsfemail.setText(rs.getString("sfemail"));
									txtsfmobile.setText(rs.getString("sfmobile"));
									txtpassword.setText(rs.getString("password"));
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});				
				 
				 p.setLayout(new BorderLayout());
				
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
					String query="DELETE FROM staffdetails WHERE sfid="+MIDList.getSelectedItem();
				
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");loadMedIDs();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JButton updateButton = new JButton("Modify");
				txtusername.setText(null);
				txtsfname.setText(null);
				txtsfaddress.setText(null);
				txtsfid.setText(null);
				txtsfqualification.setText(null);
				txtsfemail.setText(null);
				txtsfmobile.setText(null);
				txtpassword.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(8,2));
				 p1.add(lblusername);
				 p1.add(txtusername);
				 p1.add(lblsfname);
				 p1.add(txtsfname);
				 p1.add(lblsfaddress);
				 p1.add(txtsfaddress);
				 p1.add(lblsfid);
				 p1.add(txtsfid);
				 p1.add(lblsfqualification);
				 p1.add(txtsfqualification);
				 p1.add(lblsfemail);
				 p1.add(txtsfemail);
				 p1.add(lblsfmobile);
				 p1.add(txtsfmobile);
				 p1.add(lblpassword);
				 p1.add(txtpassword);
				 
				 
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.yellow);
				 p1.setBounds(115,80,300,250);p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.pink) ;
				
				 p2 = new JPanel(new FlowLayout());
					
					 MIDList=new List(10);
					 loadMedIDs();
					 p2.add(MIDList);p2.setBackground(Color.cyan) ;
					 
					 p2.setBounds(450,150,350,180);
				 
				 
				 p. add(p1);p.add(p3);
				 p. add(p2);
				  MIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from staffdetails");
								while (rs.next()) 
								{
									if (rs.getString("sfid").equals(MIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtusername.setText(rs.getString("username"));
									txtsfname.setText(rs.getString("sfname"));
									txtsfaddress.setText(rs.getString("sfaddress"));
									txtsfid.setText(rs.getString("sfid"));
									txtsfqualification.setText(rs.getString("sfqualification"));
									txtsfemail.setText(rs.getString("sfemail"));
									txtsfmobile.setText(rs.getString("sfmobile"));
									txtpassword.setText(rs.getString("password"));
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 
				 p.setLayout(new BorderLayout());
				
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
					
				
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 try {
								
								int a=JOptionPane.showConfirmDialog(p,"Are you sure want to update:");
								if(a==JOptionPane.YES_OPTION){  
								String query="update staffdetails set username='"+txtusername.getText()+"',sfname='"+txtsfname.getText()+"',sfaddress='"+txtsfaddress.getText()+"',sfid="+txtsfid.getText()+",sfqualification='"+txtsfqualification.getText()+"',sfemail='"+txtsfemail.getText()+"',sfmobile="+txtsfmobile.getText()+",password="+txtpassword.getText()+" WHERE sfid="+MIDList.getSelectedItem();
								
								int i=statement.executeUpdate(query);
								JOptionPane.showMessageDialog(p,"\nupdated "+i+" rows succesfully");loadMedIDs();
								}
								
								
							}
							catch(SQLException deleteException){
								displaySQLErrors(deleteException);
							}
				
				 }
			
			
				 	});
			}
			});
		
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("View Staff Details");
				//view1.setAlignment(Label.CENTER); 
				Font myFont = new Font("Serif",Font.BOLD,50);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p2=new JPanel();
				p1.add(view1);
				p2.add(viewButton);p1.setBackground(Color.cyan) ;p2.setBackground(Color.yellow) ;
				p.add(p1);p.add(p2); p.setLayout(new FlowLayout());
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						      
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("Staff details"); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						       model.addColumn("username");
						       model.addColumn("sfanme");
						       model.addColumn("sfaddress");
						       model.addColumn("sfid");
						       model.addColumn("sfqualification");
						       model.addColumn("sfemail");
						       model.addColumn("sfmobile");
						       model.addColumn("password");
						      
						      
						      
						       try {
									
									rs=statement.executeQuery("select * from staffdetails");
									while(rs.next())
									{
										 model.addRow(new Object[]{rs.getString("username"), rs.getString("sfname"),rs.getString("sfaddress"),rs.getString("sfid"),rs.getString("sfqualification"),rs.getString("sfemail"),rs.getString("sfmobile"),rs.getString("password")});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 300, 300); 
						  
						        
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        
						        f.setSize(800, 400); 
						      
						        f.setVisible(true); 
						       
						        
						    } 
						        
				
				 
			
			
				 	});
				
			        
				
			}
			
		});
		
	}
}
