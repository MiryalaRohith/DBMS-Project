package sfnp;
 

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class userinterface extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private JMenuBar mnu;
	
	private JMenu mnusubjectdetails;
	private JMenu mnustaffsubjects;
	private JMenu mnustaffdetails;
	private JMenu mnustudentdetails;
	private JMenu mnustudentquery;
	private JMenu mnuassesmentdetails;
	private JMenu mnulogin;
	
	
	private JMenuItem insert1,update1,delete1,view1;
	private JMenuItem insert2,update2,delete2,view2;
	private JMenuItem insert3,update3,delete3,view3;
	private JMenuItem insert4,update4,delete4,view4;
	private JMenuItem insert5,update5,delete5,view5;
	private JMenuItem insert6,update6,delete6,view6;
	private JMenuItem insert7,update7,delete7,view7;
	
	
	private JLabel labelName;

	
	private static JPanel p0,p1;
	
	void initialize() {
		mnu=new JMenuBar();
		
		mnusubjectdetails= new JMenu("subjectdetails");
		mnustaffsubjects= new JMenu("staffsubjects");
		mnustaffdetails= new JMenu("staffdetails");
		mnustudentdetails= new JMenu("studentdetails");
		mnustudentquery= new JMenu("studentquery");
		mnuassesmentdetails= new JMenu("assesmentdetails");
		mnulogin= new JMenu("login");
		labelName=new JLabel("Student Faculty Networking Platform");
		 p1=new JPanel();
		p0=new JPanel();
		insert1=new JMenuItem("Insert");
		update1=new JMenuItem("Update");
		delete1=new JMenuItem("Delete");
		view1=new JMenuItem("View");
		insert2=new JMenuItem("Insert");
		update2=new JMenuItem("Update");
		delete2=new JMenuItem("Delete");
		view2=new JMenuItem("View");
		insert3=new JMenuItem("Insert");
		update3=new JMenuItem("Update");
		delete3=new JMenuItem("Delete");
		view3=new JMenuItem("View");
		insert4=new JMenuItem("Insert");
		update4=new JMenuItem("Update");
		delete4=new JMenuItem("Delete");
		view4=new JMenuItem("View");
		insert5=new JMenuItem("Insert");
		update5=new JMenuItem("Update");
		delete5=new JMenuItem("Delete");
		view5=new JMenuItem("View");
		insert6=new JMenuItem("Insert");
		update6=new JMenuItem("Update");
		delete6=new JMenuItem("Delete");
		view6=new JMenuItem("View");
		insert7=new JMenuItem("Insert");
		update7=new JMenuItem("Update");
		delete7=new JMenuItem("Delete");
		view7=new JMenuItem("View");
		insert1=new JMenuItem("Insert");
		update1=new JMenuItem("Update");
		delete1=new JMenuItem("Delete");
		view1=new JMenuItem("View");
	}
	void addComponentsToFrame() {
		
		if(loginpage.s.equals("Admin"))
		{
		mnusubjectdetails.add(insert1);
		 mnusubjectdetails.add(delete1);
		mnusubjectdetails.add(update1);
		mnusubjectdetails.add(view1);
		  mnustaffsubjects.add(insert2);
		mnustaffsubjects.add(delete2);
		mnustaffsubjects.add(update2);
		mnustaffsubjects.add(view2);
		mnustaffdetails.add(insert3);
		mnustaffdetails.add(delete3);
		mnustaffdetails.add(update3);
		mnustaffdetails.add(view3);
		  mnustudentdetails.add(insert4);
		mnustudentdetails.add(delete4);
		mnustudentdetails.add(update4);
		mnustudentdetails.add(view4);
		 mnustudentquery.add(insert5);
		 mnustudentquery.add(delete5);
		mnustudentquery.add(update5);
		mnustudentquery.add(view5);
		 mnuassesmentdetails.add(insert6);
		mnuassesmentdetails.add(delete6);
		mnuassesmentdetails.add(update6);
		mnuassesmentdetails.add(view6);
		mnulogin.add(insert7);
		mnulogin.add(delete7);
		mnulogin.add(update7);
		mnulogin.add(view7);
		 mnu.add(mnusubjectdetails);
		 mnu.add(mnustaffsubjects);
		 mnu.add(mnustaffdetails);
		mnu.add(mnustudentdetails);
		 mnu.add(mnustudentquery);
		 mnu.add(mnuassesmentdetails);
		 mnu.add(mnulogin);
		}
		else if(loginpage.s.equals("Staff"))
		{
			mnusubjectdetails.add(insert1);
			 mnusubjectdetails.add(delete1);
			mnusubjectdetails.add(update1);
			mnusubjectdetails.add(view1);
			mnustaffsubjects.add(insert2);
			mnustaffsubjects.add(delete2);
			mnustaffsubjects.add(update2);
			mnustaffsubjects.add(view2);
			/*mnustaffdetails.add(insert3);
			mnustaffdetails.add(delete3);*/
			mnustaffdetails.add(update3);
			mnustaffdetails.add(view3);
			  mnustudentdetails.add(insert4);
			mnustudentdetails.add(delete4);
			mnustudentdetails.add(update4);
			mnustudentdetails.add(view4);
			 mnustudentquery.add(insert5);
			 mnustudentquery.add(delete5);
			mnustudentquery.add(update5);
			mnustudentquery.add(view5);
			 mnuassesmentdetails.add(insert6);
			mnuassesmentdetails.add(delete6);
			mnuassesmentdetails.add(update6);
			mnuassesmentdetails.add(view6);
			
			 mnu.add(mnusubjectdetails);
			 mnu.add(mnustaffsubjects);
			 mnu.add(mnustaffdetails);
			mnu.add(mnustudentdetails);
			 mnu.add(mnustudentquery);
			 mnu.add(mnuassesmentdetails);
			
			 
		}
		else if(loginpage.s.equals("Student"))
		{
			//mnustudents.add(insert2);
			//mnustudents.add(delete2);
			//mnustudents.add(update2);
			mnusubjectdetails.add(view1);
			//mnuassignments.add(insert4);
			//mnuassignments.add(delete4);
			//mnuassignments.add(update4);
			mnustaffsubjects.add(view2);
			//mnuviews.add(insert5);
			//mnuviews.add(delete5);
			//mnuviews.add(update5);
			mnustudentdetails.add(view4);
			 mnustudentquery.add(insert5);
			 mnustudentquery.add(view5);
			mnuassesmentdetails.add(view6);
			 mnu.add(mnusubjectdetails);
			 mnu.add(mnustaffsubjects);
			 
			mnu.add(mnustudentdetails);
			 mnu.add(mnustudentquery);
			 mnu.add(mnuassesmentdetails);
			
		}
		 setJMenuBar(mnu); 
		 p1.add(labelName);p1.setAlignmentY(CENTER_ALIGNMENT); 
		p1.setBounds(500,500,800,100);
		p0.add(p1);
		p0.setBackground(Color.yellow);
		 add(p0);
		
		
	}
void closeWindow(){
		try {
			int a=JOptionPane.showConfirmDialog(this,"Are you sure want to Quit Student Faculty Networking Platform:");
			if(a==JOptionPane.YES_OPTION){  
				JOptionPane.showMessageDialog(this,
					    "Thank you!\nExiting  Student Faculty Networking Platform","Quit",
					    JOptionPane.WARNING_MESSAGE);
				System.exit(0);
			}
			else if (a== JOptionPane.NO_OPTION) {
				setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			}
			else if (a== JOptionPane.CANCEL_OPTION) {
				setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			}
		}
			catch(Exception e) {
				System.out.println(e);
				}
	}
void register() {
		subjectdetails subjectd=new subjectdetails(p0,userinterface.this,insert1,delete1,update1,view1);
		subjectd.buildGUI();
		staffsubjects staff=new staffsubjects(p0,userinterface.this,insert2,delete2,update2,view2); 
		staff.buildGUI();
		staffdetails staffd=new staffdetails(p0,userinterface.this,insert3,delete3,update3,view3); 
		staffd.buildGUI();
		studentdetails studentd=new studentdetails(p0,userinterface.this,insert4,delete4,update4,view4); 
		studentd.buildGUI();
		studentquery studentq=new studentquery (p0,userinterface.this,insert5,delete5,update5,view5); 
		studentq.buildGUI();
		assesmentdetails assessmentd=new assesmentdetails(p0,userinterface.this,insert6,delete6,update6,view6); 
		assessmentd.buildGUI();
		login l=new login(p0,userinterface.this,insert7,delete7,update7,view7);
		l.buildGUI();
		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent we) 
			{ 
				closeWindow();
			} 
		}); 
		
}
	
public userinterface() {
		initialize();
		addComponentsToFrame();
		register();
		pack();
		setTitle("Student Faculty Networking Platform");
		setSize(800,800);
		setVisible(true);
	}
}


