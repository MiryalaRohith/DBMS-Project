package sfnp;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
public class staffsubjects
{
/**
 * 
 */
private static final long serialVersionUID = 1L;
private JButton insertButton,deleteButton,updateButton,viewButton;
private JPanel p1,p2,p3,p;
private JLabel lblsubjects,lblcourse,lblsfid,lblallotid,lblsubid,lblsemester;
private JTextField txtsubjects,txtcourse,txtsfid,txtallotid,txtsubid,txtsemester;

private List MIDList;
Connection con;ResultSet rs;
Statement statement;
private JFrame frame;
private JMenuItem insert,delete,update,view;
public staffsubjects(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
{
	
	try 
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
	} 
	catch (Exception e) 
	{
		System.err.println("Unable to find and load driver");
		System.exit(1);
	}
	connectToDB();
	
	this.frame=frame;
	this.insert=insert;
	this.delete=delete;
	this.update=update;
	this.view=view;
	
	lblsubjects=new JLabel("Subjects");
	lblcourse=new JLabel("Course");
	lblsfid=new JLabel("Sfid");
	lblallotid=new JLabel("Allot id");
	lblsubid=new JLabel("Subject id");
	lblsemester=new JLabel("Semester");

	txtsubjects=new JTextField(50);
	txtcourse=new JTextField(50);
	txtsfid=new JTextField(20);
	txtallotid=new JTextField(20);
	txtsubid=new JTextField(20);
	txtsemester=new JTextField(10);
	
	this.p=p;
	
	
	
}

public void connectToDB() 
{
	try {
	  
	
	Connection con=DriverManager.getConnection(  
	"jdbc:oracle:thin:@localhost:1521:xe","rohith","vasavi");  
	  
	 
	statement=con.createStatement(); 
	statement.executeUpdate("commit");
	
	
	}
	catch (SQLException connectException) 
	{
	  System.out.println(connectException.getMessage());
	  System.out.println(connectException.getSQLState());
	  System.out.println(connectException.getErrorCode());
	  System.exit(1);
	}
}
private void displaySQLErrors(SQLException e) 
{
	JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	
	
}
public void loadMedIDs() {
	try {
		MIDList.removeAll();
		rs=statement.executeQuery("select subid from staffsubjects");
		while(rs.next()) {
			MIDList.add(rs.getString("subid"));
		}
		}
	catch(SQLException e) {
		displaySQLErrors(e);
	}
}

public void buildGUI() {
	
	
	
	insert.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			insertButton=new JButton("Submit");
			txtsubjects.setText(null);
			txtcourse.setText(null);
			txtsfid.setText(null);
			txtallotid.setText(null);
			txtsubid.setText(null);
			txtsemester.setText(null);
			
			
			p.removeAll();
			frame.invalidate();
			frame.validate();
			frame.repaint();
			
			
			p1=new JPanel();
		
			 p1.setLayout(new GridLayout(6,2));
			 p1.add(lblsubjects);
			 p1.add(txtsubjects);
			 p1.add(lblcourse);
			 p1.add(txtcourse);
			 p1.add(lblsfid);
			 p1.add(txtsfid);
			 p1.add(lblallotid);
			 p1.add(txtallotid);
			 p1.add(lblsubid);
			 p1.add(txtsubid);
			 p1.add(lblsemester);
			 p1.add(txtsemester);
			
			
			 p3=new JPanel(new FlowLayout());
			 p3.add(insertButton);
			 //p1.add(txtf1);
			 p3.setBackground(Color.yellow);
			 p1.setBounds(115,80,300,250);p3.setBounds(200,350,75,35);
			 p1.setBackground(Color.pink) ;
			 
			
				 
			 
			
			 p2 = new JPanel(new FlowLayout());
				
				 MIDList=new List(10);
				 loadMedIDs();
				 p2.add(MIDList);p2.setBackground(Color.cyan) ;
				 
				 p2.setBounds(450,150,350,180);
			 
			 
			 p. add(p1);p.add(p3);
			 p. add(p2);
			 
			
			 p.setLayout(new BorderLayout());
			
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				
			 insertButton.addActionListener(new ActionListener() {
				 @Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub	 
			try {
				String query="INSERT INTO staffsubjects VALUES('"+txtsubjects.getText()+"','"+txtcourse.getText()+"',"+txtsfid.getText()+","+txtallotid.getText()+","+txtsubid.getText()+","+txtsemester.getText()+")";
				
				int i=statement.executeUpdate(query);
				JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully");loadMedIDs();
				
				
				
			}
			catch(SQLException insertException){
				displaySQLErrors(insertException);
			}
			
			 }
		
		
			 	});
		}
		});

	delete.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			deleteButton=new JButton("delete");
			txtsubjects.setText(null);
			txtcourse.setText(null);
			txtsfid.setText(null);
			txtallotid.setText(null);
			txtsubid.setText(null);
			txtsemester.setText(null);
			
			
			p.removeAll();
			frame.invalidate();
			frame.validate();
			frame.repaint();
			
			
			p1=new JPanel();
		
			 p1.setLayout(new GridLayout(6,2));
			 p1.add(lblsubjects);
			 p1.add(txtsubjects);
			 p1.add(lblcourse);
			 p1.add(txtcourse);
			 p1.add(lblsfid);
			 p1.add(txtsfid);
			 p1.add(lblallotid);
			 p1.add(txtallotid);
			 p1.add(lblsubid);
			 p1.add(txtsubid);
			 p1.add(lblsemester);
			 p1.add(txtsemester);
			
			
			
			 p3=new JPanel(new FlowLayout());
			 p3.add(deleteButton);
			 //p1.add(txtf1);
			 p3.setBackground(Color.yellow);
			 p1.setBounds(115,80,300,250);p3.setBounds(200,350,75,35);
			 p1.setBackground(Color.pink) ;
			 
			
				 
			// p1.setBounds(100,100,500,300);
			
			 p2 = new JPanel(new FlowLayout());
				
				 MIDList=new List(10);
				 loadMedIDs();
				 p2.add(MIDList);p2.setBackground(Color.cyan) ;
				 
				 p2.setBounds(450,150,350,180);
			 
			 
			 p. add(p1);
			 p.add(p3);
			 p. add(p2);
			  MIDList.addItemListener(new ItemListener()
				{
					public void itemStateChanged(ItemEvent e) 
					{
						try 
						{
							rs=statement.executeQuery("select * from staffsubjects");
							while (rs.next()) 
							{
								if (rs.getString("subid").equals(MIDList.getSelectedItem()))
								break;
							}
							if (!rs.isAfterLast()) 
							{
								txtsubjects.setText(rs.getString("subjects"));
								txtcourse.setText(rs.getString("course"));
								txtsfid.setText(rs.getString("sfid"));
								txtallotid.setText(rs.getString("allotid"));
								txtsubid.setText(rs.getString("subid"));
								txtsemester.setText(rs.getString("semester"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}
					}
				});				
			 
			 p.setLayout(new BorderLayout());
			
			frame.add(p);
			frame.setSize(800,800);
			frame.validate();
			
			 deleteButton.addActionListener(new ActionListener() {
				 @Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub	 
			try {
				
				int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
				if(a==JOptionPane.YES_OPTION){  
				String query="DELETE FROM staffsubjects WHERE subid="+MIDList.getSelectedItem();
			
				int i=statement.executeUpdate(query);
				JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");loadMedIDs();
				}
				
				
			}
			catch(SQLException deleteException){
				displaySQLErrors(deleteException);
			}
			
			 }
		
		
			 	});
		}
		});
	
	update.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			JButton updateButton = new JButton("Modify");
			txtsubjects.setText(null);
			txtcourse.setText(null);
			txtsfid.setText(null);
			txtallotid.setText(null);
			txtsubid.setText(null);
			txtsemester.setText(null);
			
			p.removeAll();
			frame.invalidate();
			frame.validate();
			frame.repaint();
			
			
			p1=new JPanel();
		
			 p1.setLayout(new GridLayout(6,2));
			 p1.add(lblsubjects);
			 p1.add(txtsubjects);
			 p1.add(lblcourse);
			 p1.add(txtcourse);
			 p1.add(lblsfid);
			 p1.add(txtsfid);
			 p1.add(lblallotid);
			 p1.add(txtallotid);
			 p1.add(lblsubid);
			 p1.add(txtsubid);
			 p1.add(lblsemester);
			 p1.add(txtsemester);
			 p3=new JPanel(new FlowLayout());
			 p3.add(updateButton);
			 //p1.add(txtf1);
			 p3.setBackground(Color.yellow);
			 p1.setBounds(115,80,300,250);p3.setBounds(200,350,75,35);
			 p1.setBackground(Color.pink) ;
			
			 p2 = new JPanel(new FlowLayout());
				
				 MIDList=new List(10);
				 loadMedIDs();
				 p2.add(MIDList);p2.setBackground(Color.cyan) ;
				 
				 p2.setBounds(450,150,350,180);
			 
			 
			 p. add(p1);p.add(p3);
			 p. add(p2);
			  MIDList.addItemListener(new ItemListener()
				{
					public void itemStateChanged(ItemEvent e) 
					{
						try 
						{
							rs=statement.executeQuery("select * from staffsubjects");
							while (rs.next()) 
							{
								if (rs.getString("subid").equals(MIDList.getSelectedItem()))
								break;
							}
							if (!rs.isAfterLast()) 
							{
								txtsubjects.setText(rs.getString("subjects"));
								txtcourse.setText(rs.getString("course"));
								txtsfid.setText(rs.getString("sfid"));
								txtallotid.setText(rs.getString("allotid"));
								txtsubid.setText(rs.getString("subid"));
								txtsemester.setText(rs.getString("semester"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}
					}
				});			
			 
			 p.setLayout(new BorderLayout());
			
			frame.add(p);
			frame.setSize(800,800);
			frame.validate();
				
			
			 updateButton.addActionListener(new ActionListener() {
				 @Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub	 
					 try {
							
							int a=JOptionPane.showConfirmDialog(p,"Are you sure want to update:");
							if(a==JOptionPane.YES_OPTION){  
							String query="update staffsubjects set subjects='"+txtsubjects.getText()+"',course='"+txtcourse.getText()+"',sfid="+txtsfid.getText()+",allotid="+txtallotid.getText()+",subid="+txtsubid.getText()+",semester="+txtsemester.getText()+" WHERE subid="+MIDList.getSelectedItem();
							
							int i=statement.executeUpdate(query);
							JOptionPane.showMessageDialog(p,"\nupdated "+i+" rows succesfully");loadMedIDs();
							}
							
							
						}
						catch(SQLException deleteException){
							displaySQLErrors(deleteException);
						}
			
			 }
		
		
			 	});
		}
		});
	
	view.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			
			p.removeAll();
			frame.invalidate();
			frame.validate();
			frame.repaint();
			
			Label view1=new Label("View Staff Subject");
			//view1.setAlignment(Label.CENTER); 
			Font myFont = new Font("Serif",Font.BOLD,50);
			view1.setFont((myFont));
			viewButton=new JButton("View");
			p1=new JPanel();
			p2=new JPanel();
			p1.add(view1);
			p2.add(viewButton);p1.setBackground(Color.cyan) ;p2.setBackground(Color.yellow) ;
			p.add(p1);p.add(p2); p.setLayout(new FlowLayout());
			frame.add(p);
			frame.setSize(800,800);
			frame.validate();
			 viewButton.addActionListener(new ActionListener() {
				 @Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub	 
					 JFrame f; 
					      
					    JTable j; 
					
					        f = new JFrame(); 
					  
					  
					        f.setTitle("Staff Subjects"); 
					        
					       
					        DefaultTableModel model = new DefaultTableModel(); 
					        j = new JTable(model); 
					       model.addColumn("subjects");
					       model.addColumn("course");
					       model.addColumn("sfid");
					       model.addColumn("allotid");
					       model.addColumn("subid");
					       model.addColumn("semester");
					      
					      
					      
					       try {
								
								rs=statement.executeQuery("select * from staffsubjects");
								while(rs.next()) {
									 model.addRow(new Object[]{rs.getString("subjects"), rs.getString("course"),rs.getString("sfid"),rs.getString("allotid"),rs.getString("subid"),rs.getString("semester")});
								}
								}
							catch(SQLException viewException) {
								displaySQLErrors(viewException);
							}
							j.setEnabled(false);
					        j.setBounds(30, 40, 300, 300); 
					  
					        
					        JScrollPane sp = new JScrollPane(j); 
					        f.add(sp); 
					        
					        f.setSize(800, 400); 
					      
					        f.setVisible(true); 
					       
					        
					    } 
					        
			
			 
		
		
			 	});
			
		        
			
		}
		
	});
	
}



}
