package sfnp;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
public class subjectdetails{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton insertButton,deleteButton,updateButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lblsemester,lblcoursename,lbltimetable,lblsubject1,lblsubject2,lblsubject3,lblsubject4,lblsubject5,lblsubject6,lblsubject7,lblsubject8,lblsubject9,lblsubject10,lblsubid;
	private JTextField txtsemester,txtcoursename,txttimetable,txtsubject1,txtsubject2,txtsubject3,txtsubject4,txtsubject5,txtsubject6,txtsubject7,txtsubject8,txtsubject9,txtsubject10,txtsubid;
	
	private List MIDList;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public subjectdetails(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		
		lblsemester=new JLabel("Semester");
		lblcoursename=new JLabel("Course Name");
		lbltimetable=new JLabel("Time Table");
		lblsubject1=new JLabel("Subject-1");
		lblsubject2=new JLabel("Subject-2");
		lblsubject3=new JLabel("Subject-3");
		lblsubject4=new JLabel("Subject-4");
		lblsubject5=new JLabel("Subject-5");
		lblsubject6=new JLabel("Subject-6");
		lblsubject7=new JLabel("Subject-7");
		lblsubject8=new JLabel("Subject-8");
		lblsubject9=new JLabel("Subject-9");
		lblsubject10=new JLabel("Subject-10");
		lblsubid=new JLabel("Subject id");
		
		
		
		txtsemester=new JTextField(10);
		txtcoursename=new JTextField(15);
		txttimetable=new JTextField(1000);
		txtsubject1=new JTextField(50);
		txtsubject2=new JTextField(50);
		txtsubject3=new JTextField(50);
		txtsubject4=new JTextField(50);
		txtsubject5=new JTextField(50);
		txtsubject6=new JTextField(50);
		txtsubject7=new JTextField(50);
		txtsubject8=new JTextField(50);
		txtsubject9=new JTextField(50);
		txtsubject10=new JTextField(50);
		txtsubid=new JTextField(20);
		
		this.p=p;
		
		
		
	}

	public void connectToDB() 
    {
		try {
		  
		
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","rohith","vasavi");  
		  
		 
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		
		
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
		
		
	}
	public void loadMedIDs() {
		try {
			MIDList.removeAll();
			rs=statement.executeQuery("select subid from subjectdetails");
			while(rs.next()) {
				MIDList.add(rs.getString("subid"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}

	public void buildGUI() {
		
		
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				insertButton=new JButton("Submit");
				txtsemester.setText(null);
				txtcoursename.setText(null);
				txttimetable.setText(null);
				txtsubject1.setText(null);
				txtsubject2.setText(null);
				txtsubject3.setText(null);
				txtsubject4.setText(null);
				txtsubject5.setText(null);
				txtsubject6.setText(null);
				txtsubject7.setText(null);
				txtsubject8.setText(null);
				txtsubject9.setText(null);
				txtsubject10.setText(null);
				txtsubid.setText(null);
								
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(13,2));
				 p1.add(lblsemester);
				 p1.add(txtsemester);
				 p1.add(lblcoursename);
				 p1.add(txtcoursename);
				 p1.add(lbltimetable);
				 p1.add(txttimetable);
				 p1.add(lblsubject1);
				 p1.add(txtsubject1);
				 p1.add(lblsubject2);
				 p1.add(txtsubject2);
				 p1.add(lblsubject3);
				 p1.add(txtsubject3);
				 p1.add(lblsubject4);
				 p1.add(txtsubject4);
				 p1.add(lblsubject5);
				 p1.add(txtsubject5);
				 p1.add(lblsubject6);
				 p1.add(txtsubject6);
				 p1.add(lblsubject7);
				 p1.add(txtsubject7);
				 p1.add(lblsubject8);
				 p1.add(txtsubject8);
				 p1.add(lblsubject9);
				 p1.add(txtsubject9);
				 p1.add(lblsubject10);
				 p1.add(txtsubject10);
				 p1.add(lblsubid);
				 p1.add(txtsubid);
				
				 p3=new JPanel(new FlowLayout());
				 p3.add(insertButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.yellow);
				 p1.setBounds(115,80,300,250);p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.pink) ;
				 
				
					 
				 
				
				 p2 = new JPanel(new FlowLayout());
					
					 MIDList=new List(10);
					 loadMedIDs();
					 p2.add(MIDList);p2.setBackground(Color.cyan) ;
					 
					 p2.setBounds(450,150,350,180);
				 
				 
				 p. add(p1);p.add(p3);
				 p. add(p2);
				 
				
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(1000,1000);
					frame.validate();
					
				 insertButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO subjectdetails VALUES("+txtsemester.getText()+",'"+txtcoursename.getText()+"','"+txttimetable.getText()+"','"+txtsubject1.getText()+"','"+txtsubject2.getText()+"','"+txtsubject3.getText()+"','"+txtsubject4.getText()+"','"+txtsubject5.getText()+"','"+txtsubject6.getText()+"','"+txtsubject7.getText()+"','"+txtsubject8.getText()+"','"+txtsubject9.getText()+"','"+txtsubject10.getText()+"',"+txtsubid.getText()+")";
					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully");loadMedIDs();
					
					
					
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("delete");
				
				txtsemester.setText(null);
				txtcoursename.setText(null);
				txttimetable.setText(null);
				txtsubject1.setText(null);
				txtsubject2.setText(null);
				txtsubject3.setText(null);
				txtsubject4.setText(null);
				txtsubject5.setText(null);
				txtsubject6.setText(null);
				txtsubject7.setText(null);
				txtsubject8.setText(null);
				txtsubject9.setText(null);
				txtsubject10.setText(null);
				txtsubid.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(13,2));
				 p1.add(lblsemester);
				 p1.add(txtsemester);
				 p1.add(lblcoursename);
				 p1.add(txtcoursename);
				 p1.add(lbltimetable);
				 p1.add(txttimetable);
				 p1.add(lblsubject1);
				 p1.add(txtsubject1);
				 p1.add(lblsubject2);
				 p1.add(txtsubject2);
				 p1.add(lblsubject3);
				 p1.add(txtsubject3);
				 p1.add(lblsubject4);
				 p1.add(txtsubject4);
				 p1.add(lblsubject5);
				 p1.add(txtsubject5);
				 p1.add(lblsubject6);
				 p1.add(txtsubject6);
				 p1.add(lblsubject7);
				 p1.add(txtsubject7);
				 p1.add(lblsubject8);
				 p1.add(txtsubject8);
				 p1.add(lblsubject9);
				 p1.add(txtsubject9);
				 p1.add(lblsubject10);
				 p1.add(txtsubject10);
				 p1.add(lblsubid);
				 p1.add(txtsubid);
				
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.yellow);
				 p1.setBounds(115,80,300,250);p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.pink) ;
				 
				
					 
				// p1.setBounds(100,100,500,300);
				
				 p2 = new JPanel(new FlowLayout());
					
					 MIDList=new List(10);
					 loadMedIDs();
					 p2.add(MIDList);p2.setBackground(Color.cyan) ;
					 
					 p2.setBounds(450,150,350,180);
				 
				 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				  MIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from subjectdetails");
								while (rs.next()) 
								{
									if (rs.getString("subid").equals(MIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtsemester.setText(rs.getString("semester"));
									txtcoursename.setText(rs.getString("coursename"));
									txttimetable.setText(rs.getString("timetable"));
									txtsubject1.setText(rs.getString("subject1"));
									txtsubject2.setText(rs.getString("subject2"));
									txtsubject3.setText(rs.getString("subject3"));
									txtsubject4.setText(rs.getString("subject4"));
									txtsubject5.setText(rs.getString("subject5"));
									txtsubject6.setText(rs.getString("subject6"));
									txtsubject7.setText(rs.getString("subject7"));
									txtsubject8.setText(rs.getString("subject8"));
									txtsubject9.setText(rs.getString("subject9"));
									txtsubject10.setText(rs.getString("subject10"));
									txtsubid.setText(rs.getString("subid"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});				
				 
				 p.setLayout(new BorderLayout());
				
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
					String query="DELETE FROM subjectdetails WHERE subid="+MIDList.getSelectedItem();
				
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");loadMedIDs();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JButton updateButton = new JButton("Modify");
				txtsemester.setText(null);
				txtcoursename.setText(null);
				txttimetable.setText(null);
				txtsubject1.setText(null);
				txtsubject2.setText(null);
				txtsubject3.setText(null);
				txtsubject4.setText(null);
				txtsubject5.setText(null);
				txtsubject6.setText(null);
				txtsubject7.setText(null);
				txtsubject8.setText(null);
				txtsubject9.setText(null);
				txtsubject10.setText(null);
				txtsubid.setText(null);
				
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(13,2));
				 p1.add(lblsemester);
				 p1.add(txtsemester);
				 p1.add(lblcoursename);
				 p1.add(txtcoursename);
				 p1.add(lbltimetable);
				 p1.add(txttimetable);
				 p1.add(lblsubject1);
				 p1.add(txtsubject1);
				 p1.add(lblsubject2);
				 p1.add(txtsubject2);
				 p1.add(lblsubject3);
				 p1.add(txtsubject3);
				 p1.add(lblsubject4);
				 p1.add(txtsubject4);
				 p1.add(lblsubject5);
				 p1.add(txtsubject5);
				 p1.add(lblsubject6);
				 p1.add(txtsubject6);
				 p1.add(lblsubject7);
				 p1.add(txtsubject7);
				 p1.add(lblsubject8);
				 p1.add(txtsubject8);
				 p1.add(lblsubject9);
				 p1.add(txtsubject9);
				 p1.add(lblsubject10);
				 p1.add(txtsubject10);
				 p1.add(lblsubid);
				 p1.add(txtsubid);
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.yellow);
				 p1.setBounds(115,80,300,250);p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.pink) ;
				
				 p2 = new JPanel(new FlowLayout());
					
					 MIDList=new List(10);
					 loadMedIDs();
					 p2.add(MIDList);p2.setBackground(Color.cyan) ;
					 
					 p2.setBounds(450,150,350,180);
				 
				 
				 p. add(p1);p.add(p3);
				 p. add(p2);
				  MIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from subjectdetails");
								while (rs.next()) 
								{
									if (rs.getString("subid").equals(MIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtsemester.setText(rs.getString("semester"));
									txtcoursename.setText(rs.getString("coursename"));
									txttimetable.setText(rs.getString("timetable"));
									txtsubject1.setText(rs.getString("subject1"));
									txtsubject2.setText(rs.getString("subject2"));
									txtsubject3.setText(rs.getString("subject3"));
									txtsubject4.setText(rs.getString("subject4"));
									txtsubject5.setText(rs.getString("subject5"));
									txtsubject6.setText(rs.getString("subject6"));
									txtsubject7.setText(rs.getString("subject7"));
									txtsubject8.setText(rs.getString("subject8"));
									txtsubject9.setText(rs.getString("subject9"));
									txtsubject10.setText(rs.getString("subject10"));
									txtsubid.setText(rs.getString("subid"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 
				 p.setLayout(new BorderLayout());
				
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
					
				
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 try {
								
								int a=JOptionPane.showConfirmDialog(p,"Are you sure want to update:");
								if(a==JOptionPane.YES_OPTION){  
								String query="update subjectdetails set semester="+txtsemester.getText()+",coursename='"+txtcoursename.getText()+"',timetable='"+txttimetable.getText()+"',subject1='"+txtsubject1.getText()+"',subject2='"+txtsubject2.getText()+"',subject3='"+txtsubject3.getText()+"',subject4='"+txtsubject4.getText()+"',subject5='"+txtsubject5.getText()+"',subject6='"+txtsubject6.getText()+"',subject7='"+txtsubject7.getText()+"',subject8='"+txtsubject8.getText()+"',subject9='"+txtsubject9.getText()+"',subject10='"+txtsubject10.getText()+"',subid="+txtsubid.getText()+" WHERE subid="+MIDList.getSelectedItem();
								
								int i=statement.executeUpdate(query);
								JOptionPane.showMessageDialog(p,"\nupdated "+i+" rows succesfully");loadMedIDs();
								}
								
								
							}
							catch(SQLException deleteException){
								displaySQLErrors(deleteException);
							}
				
				 }
			
			
				 	});
			}
			});
		
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("Subject view");
				//view1.setAlignment(Label.CENTER); 
				Font myFont = new Font("Serif",Font.BOLD,50);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p2=new JPanel();
				p1.add(view1);
				p2.add(viewButton);p1.setBackground(Color.cyan) ;p2.setBackground(Color.yellow) ;
				p.add(p1);p.add(p2); p.setLayout(new FlowLayout());
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						      
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("Subject details"); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						       model.addColumn("semester");
						       model.addColumn("coursename");
						       model.addColumn("timetable");
						       model.addColumn("subject1");
						       model.addColumn("subject2");
						       model.addColumn("subject3");
						       model.addColumn("subject4");
						       model.addColumn("subject5");
						       model.addColumn("subject6");
						       model.addColumn("subject7");
						       model.addColumn("subject8");
						       model.addColumn("subject9");
						       model.addColumn("subject10");
						       model.addColumn("subid");
						      
						      
						       try {
									
									rs=statement.executeQuery("select * from subjectdetails");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("semester"), rs.getString("coursename"),rs.getString("timetable"),rs.getString("subject1"),rs.getString("subject2"),rs.getString("subject3"),rs.getString("subject4"),rs.getString("subject5"),rs.getString("subject6"),rs.getString("subject7"),rs.getString("subject8"),rs.getString("subject9"),rs.getString("subject10"),rs.getString("subid")});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 300, 300); 
						  
						        
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        
						        f.setSize(800, 400); 
						      
						        f.setVisible(true); 
						       
						        
						    } 
						        
				
				 
			
			
				 	});
				
			        
				
			}
			
		});
		
	}
	
	
	
}
	
	

