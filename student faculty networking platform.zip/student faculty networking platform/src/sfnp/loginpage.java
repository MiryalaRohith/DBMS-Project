package sfnp;


import java.awt.BorderLayout;
import java.awt.EventQueue;
import sfnp.*;
import java.sql.*;
import javax.sql.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class loginpage extends JFrame
{
	private static final long serialVersionUID = 1L;
	private JFrame StudentFacultyNetworkingSystem;
	private JTextField txtuserid;
	private JPasswordField txtpwd;
	private JPanel contentPane;
	static String s;
	static String str1;
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run()
			{
				try 
				{
					loginpage window = new loginpage();
					window.StudentFacultyNetworkingSystem.setVisible(true);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				} 
			}
		});
	}
	public loginpage() {
		initialize();
	}
	JButton btnLogin;
	JLabel lblNewLabel_2;
	private void initialize() 
	{
		StudentFacultyNetworkingSystem = new JFrame();
		StudentFacultyNetworkingSystem.setTitle("Student Faculty Networking System");
		StudentFacultyNetworkingSystem.setBounds(400, 400, 450, 300);
		StudentFacultyNetworkingSystem.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		StudentFacultyNetworkingSystem.getContentPane().setLayout(null);		
		JMenuBar menuBar = new JMenuBar();
		StudentFacultyNetworkingSystem.setJMenuBar(menuBar);
		JMenu mnNewMenu = new JMenu("Login");
		mnNewMenu.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				btnLogin.setVisible(true);
				lblNewLabel_2.setVisible(false);
				
			}
		});
		menuBar.add(mnNewMenu);
		txtuserid = new JTextField();
		txtuserid.setBounds(198, 47, 96, 20);
		StudentFacultyNetworkingSystem.getContentPane().add(txtuserid);
		txtuserid.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Login Id");
		lblNewLabel.setBounds(76, 50, 84, 14);
		StudentFacultyNetworkingSystem.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setBounds(76, 88, 84, 14);
		StudentFacultyNetworkingSystem.getContentPane().add(lblNewLabel_1);
		
		/*lblNewLabel_2 = new JLabel("User Name");
		lblNewLabel_2.setBounds(76, 126, 84, 14);
		StudentAssignmentsTracker.getContentPane().add(lblNewLabel_2);
		lblNewLabel_2.setVisible(false);*/
		
		btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() 
		
		{
			public void actionPerformed(ActionEvent e) {
				boolean isValidUser=false;
				try 
				{
					DBconnection connect = new DBconnection();
					Connection con = connect.getConnection();
					Statement stmt=con.createStatement();
					str1=txtuserid.getText();
					String txt = "select usercategory from login where user_id = '"+txtuserid.getText()+"' and password ='"+new String(txtpwd.getPassword())+"'";
					ResultSet rs=stmt.executeQuery(txt);
					if(rs.next()) 
					{
						s=rs.getString("usercategory");
						isValidUser = true;
					}
					rs.close();
					
				}
				catch(Exception ex) {
					System.out.println(ex);
				}
				if(isValidUser) {
					userinterface h=new userinterface();
			
				}
				else 
				{
					JOptionPane.showMessageDialog(null,"Invalid login");
				}
				
			}
		});
		btnLogin.setBounds(150, 160, 89, 23);
		StudentFacultyNetworkingSystem.getContentPane().add(btnLogin);
		txtpwd = new JPasswordField();
		txtpwd.setBounds(198, 85, 96, 20);
		StudentFacultyNetworkingSystem.getContentPane().add(txtpwd);
	}
}


